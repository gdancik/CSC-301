document.body.style.backgroundColor = 'yellow';

