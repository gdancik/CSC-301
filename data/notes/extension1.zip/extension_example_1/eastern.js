
if (document.URL.indexOf("easternct.edu") < 0) {
    alert("To use this function, go to one of Eastern's pages");
} else {

    // fix the position of Eastern's header
    var h = document.getElementById("easternHeaderRow"); // easternHeaderRow
    h.style.position = "fixed";
    h.style.top = "0%";
    h.style.backgroundColor = "darkgreen";

    if (document.URL == "http://www.easternct.edu/") {
          h.style.width = "100%";
    } else {
        h.style.width = "91.8%";
    }
    page = document.getElementById("page");
    page.style.margin = "0px";
}
