// Called when the user clicks on the browser action (extension icon).

//chrome.tabs.onUpdated.addListener(function(tab) {
chrome.browserAction.onClicked.addListener(function(tab) {

  console.log("Running extension");

  chrome.tabs.executeScript({
   file: 'eastern.js'
  });
});
