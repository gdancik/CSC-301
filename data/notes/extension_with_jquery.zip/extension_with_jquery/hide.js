
// hide all images
$("img").hide();

// create a div so that the user can show/hide pictures, which
// the div is clicked
var div = document.createElement("div");
div.innerHTML = "<br>Show Pictures";
div.id = "toggle-extension-div"
div.onclick = function() {
        if (this.innerHTML == "<br>Show Pictures") {
            $("img").show();
            this.innerHTML = "<br>Hide Pictures";
        } else {
            $("img").hide();
            this.innerHTML = "<br>Show Pictures";
        }
}

// append the div to the body
document.body.append(div)

