// This script highlights all occurences of 'qry'. The variable 'qry' should
// be set before calling this script

if (typeof(qry) == "undefined") {
    qry = "Connecticut";
} else if (qry == "" || qry == " ") {
    qry = "Connecticut";
}

// original qry
var qry1 = qry

// escape characters which have special meanings in regular expressions
qry =  qry.replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g, '\\$1').
      replace(/\x08/g, '\\x08');

console.log("highlighter is running with qry = " + qry + "...");

// get all HTML from the body
var text = document.body.innerHTML;

// Create a regular expression to find all occurences of the 
//    query not inside of a tag, also specifying
// g - finds all occurences
// i - case insensitive
// m - multiline matching
// (qry) will allow us to reference the match
var findWord = RegExp("("+qry+")" + '(?![^<]*>)', "gim"); 

m = text.match(findWord);

if (m != null) {

    console.log("Search for " + qry + " finds " + m.length + " matches");

    // add <span> tags and background-color for each match
    text = text.replace(findWord, "<span style ='background-color:yellow'>$1</span>");

    // reset the inner HTML of the body
    document.body.innerHTML = text;

}
