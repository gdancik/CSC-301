function highlight(keyword) {
    window.close();
    codeString = "var qry = \"" + keyword + "\";";
    chrome.tabs.executeScript(null, {code: codeString});
    chrome.tabs.executeScript(null, {file: "highlight.js"});
}


// Chrome extensions do not allow inline Javascript in popups for security reasons; instead
// add listener for button click, in this case calling 'highlight()'
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById("btnHighlight").addEventListener("click", 
        function() {
            var search = document.getElementById('searchString').value;
            if (search == "") {
                alert("nope!");
                return;
            }
            highlight(search);
        })
});



