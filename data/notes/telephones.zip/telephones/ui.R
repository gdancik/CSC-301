# Downloaded and modified from: 
#     https://shiny.rstudio.com/gallery/telephones-by-region.html

# Rely on the 'WorldPhones' dataset in the datasets
# package (which generally comes preloaded).
library(datasets)

# Use a fluid Bootstrap layout
fluidPage(

  # Give the page a title
  titlePanel("Telephones by region"),

  # Generate a row with a sidebar
  sidebarLayout(

    # Define the sidebar with one input
    sidebarPanel(
      selectInput("region", "Region:",
                  choices=colnames(WorldPhones)),
      
      # TO DO: add a drop down box so user can select a color
      
      hr(),
      
      # TO DO: display 'Source:' in blue on the same line as the helpText
      helpText("Data from AT&T (1961) The World's Telephones.")
      
    ),
      
    # Create a spot for the barplot
    mainPanel(
      plotOutput("phonePlot")
    )

  )
)

