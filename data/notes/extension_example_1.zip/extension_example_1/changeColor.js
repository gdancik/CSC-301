if (!document.URL.includes("easternct.edu")) {
    // rgba specifies a 'red', 'green', 'blue', and 'alpha' value,
    // where 'alpha' controls the opacity

    let color  = 'rgba(238,130,238, .3)';
    document.body.style.backgroundColor = color;
}

