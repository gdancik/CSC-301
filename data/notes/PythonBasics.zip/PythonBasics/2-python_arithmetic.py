######################################################################
# arithmetic is straightforward in Python 3*
# (Note: for Python 2, you need to worry about integer division)
######################################################################

print("5 / 2 = ", 5/2)  # normal division
print("5 % 2 = ", 5%2)  # mod operator returns the remainder
print("5.0 // 2 = ", 5.0 // 2)  # integer (floor) division
print("3 squared = ", 3**2)
print()

# The shortcuts += or -= can be used:
x = 3
x+= 2 # same as x = x + 2)
print("x = ", x)
print()
