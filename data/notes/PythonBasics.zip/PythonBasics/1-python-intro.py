##################################################################
# Python Basics - Intro to Python
#   Link to download: https://www.python.org/downloads/
#   Spyder IDE: https://pythonhosted.org/spyder/
# Note: we will be using Python 3* in this class, and sripts will 
# not be compatiable with Python 2*
# For additional practice: https://docs.python.org/3/tutorial/
##################################################################

# Python Basics: this is a comment

"""
Multi-line comments begin and end with three quotes (single or double)
This is a multi-line comment
"""

# printing to the screen - text can be in single or double quotes
print("Hello World!")   
print('Hello World!')

# In Python 3, the full form of the print function is:
# print(objects, sep=' ', end='\n', file=sys.stdout, flush=False)

# does the same as above
print("Hello", "World!", sep= ' ', end = '\n')  

# Use '\n' for a newline character:
print("Hello\nGoodbye")

# skip a line
print()

# variables are not declared #
x = 4.2
y = 6
sum = x + y

# to print multiple objects, separate them with commas
# (spaces are added to separate each object)
print ("x =", x)
print ("y =", y)
print ("sum =", sum)
print ("sum =",  x + y)  # print statement may include expressions

# use + for string concatenation, but you must convert non-string objects to
# strings using 'str'
answer = "The sum of " + str(x) + " and " + str(y) + " is " + str(sum) + "."
print(answer)

# variables can be numbers, strings, or bool (True/False) values
topic = "Web scraping"
print ("Are you ready for some " + topic + "?")

compare = 5 > 0   # compare is True
print ("compare =", compare)
print()
# use 'type' function to determine the type of a variable / object
print("x is a", type(x))
print("sum is a", type(sum))
print("topic is a", type(topic))
print("compare is a", type(compare))

########################################################################
# Exercise: Use two string variables to store your first and last name.
# Then create a third string variable that stores your full name, based
# on the first two strings, and output its value
########################################################################




